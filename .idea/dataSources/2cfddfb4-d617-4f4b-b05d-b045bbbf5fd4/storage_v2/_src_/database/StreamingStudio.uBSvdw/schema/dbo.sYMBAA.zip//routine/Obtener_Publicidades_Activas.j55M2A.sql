CREATE   PROCEDURE Obtener_Publicidades_Activas
AS
BEGIN
    SELECT id_banner, url_de_imagen, url_de_publicidad, grado_de_exclusividad
    FROM dbo.Publicidad P
             JOIN dbo.Exclusividad E ON P.id_exclusividad = E.id_exclusividad
    WHERE CONVERT(DATE, fecha_de_baja, 23) > CONVERT(DATE, CURRENT_TIMESTAMP, 23)
      AND CONVERT(DATE, fecha_de_alta, 23) <= CONVERT(DATE, CURRENT_TIMESTAMP, 23)
    ORDER BY id_banner DESC
END
go

