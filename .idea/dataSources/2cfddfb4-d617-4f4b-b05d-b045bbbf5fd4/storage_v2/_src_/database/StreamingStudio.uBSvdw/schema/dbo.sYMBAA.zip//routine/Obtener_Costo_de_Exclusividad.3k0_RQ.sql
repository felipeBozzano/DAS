CREATE   PROCEDURE Obtener_Costo_de_Exclusividad @id_exclusividad INT
AS
BEGIN
    SELECT descripcion, costo
    FROM dbo.Exclusividad
    WHERE id_exclusividad = @id_exclusividad
END
go

