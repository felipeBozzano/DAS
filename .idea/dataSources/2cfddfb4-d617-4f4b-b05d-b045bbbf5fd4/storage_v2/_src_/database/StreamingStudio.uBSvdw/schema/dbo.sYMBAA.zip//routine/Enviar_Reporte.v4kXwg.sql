CREATE   PROCEDURE Enviar_Reporte @id_reporte INT
AS
BEGIN
    UPDATE dbo.Reporte
    SET estado = 2
    WHERE id_reporte = @id_reporte
END
go

