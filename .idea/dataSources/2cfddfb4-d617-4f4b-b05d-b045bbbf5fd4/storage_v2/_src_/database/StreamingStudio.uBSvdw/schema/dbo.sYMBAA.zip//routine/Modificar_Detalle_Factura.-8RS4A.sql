CREATE   PROCEDURE Modificar_Detalle_Factura @id_factura INT,
                                                    @id_detalle INT,
                                                    @precio_unitario FLOAT,
                                                    @cantidad INT,
                                                    @subtotal FLOAT,
                                                    @descripcion VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Detalle_Factura
    SET precio_unitario = @precio_unitario,
        cantidad        = @cantidad,
        subtotal        = @subtotal,
        descripcion     = @descripcion
    WHERE id_factura = @id_factura
      AND id_detalle = @id_detalle
END
go

