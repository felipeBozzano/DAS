CREATE   TRIGGER Desvincular_Federaciones
    ON dbo.Cliente_Usuario
    FOR UPDATE
    AS
BEGIN
    DELETE f
    FROM dbo.Federacion f
             JOIN inserted i ON f.id_cliente = i.id_cliente
    WHERE i.valido = 0;
END
go

