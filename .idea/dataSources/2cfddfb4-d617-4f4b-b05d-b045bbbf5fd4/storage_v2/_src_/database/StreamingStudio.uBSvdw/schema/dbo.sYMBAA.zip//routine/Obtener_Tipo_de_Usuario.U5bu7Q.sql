CREATE   PROCEDURE Obtener_Tipo_de_Usuario @id_tipo_usuario SMALLINT
AS
BEGIN
    SELECT descripcion
    FROM dbo.Tipo_Usuario
    WHERE id_tipo_usuario = @id_tipo_usuario
END
go

