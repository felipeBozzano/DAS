CREATE   PROCEDURE Registrar_Publicidad @id_publicista VARCHAR(255),
                                               @id_exclusividad VARCHAR(255),
                                               @id_banner VARCHAR(255),
                                               @codigo_publicidad VARCHAR(255),
                                               @url_de_imagen VARCHAR(255),
                                               @url_de_publicidad VARCHAR(255),
                                               @fecha_de_alta DATE,
                                               @fecha_de_baja DATE
AS
BEGIN
    INSERT INTO dbo.Publicidad(id_publicista, id_exclusividad, id_banner, codigo_publicidad, url_de_imagen,
                               url_de_publicidad, fecha_de_alta, fecha_de_baja)
    VALUES (@id_publicista, @id_exclusividad, @id_banner, @codigo_publicidad, @url_de_imagen, @url_de_publicidad,
            @fecha_de_alta, @fecha_de_baja)
END
go

