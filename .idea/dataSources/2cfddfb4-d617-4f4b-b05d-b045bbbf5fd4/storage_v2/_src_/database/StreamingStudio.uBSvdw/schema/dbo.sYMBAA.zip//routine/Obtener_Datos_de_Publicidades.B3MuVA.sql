CREATE   PROCEDURE Obtener_Datos_de_Publicidades
AS
BEGIN
    SELECT id_publicista,
           id_publicidad,
           codigo_publicidad,
           url_de_imagen,
           url_de_publicidad
    FROM dbo.Publicidad
    WHERE DAY(fecha_de_baja) >= DAY(GETDATE())
END
go

