CREATE   PROCEDURE Registrar_Clic @id_cliente INT,
                                         @id_publicidad INT,
                                         @id_plataforma INT,
                                         @id_contenido INT
AS
BEGIN
    INSERT INTO dbo.Clic(id_cliente, id_publicidad, id_plataforma, id_contenido, fecha)
    VALUES (@id_cliente, @id_publicidad, @id_plataforma, @id_contenido, CURRENT_TIMESTAMP)
END
go

