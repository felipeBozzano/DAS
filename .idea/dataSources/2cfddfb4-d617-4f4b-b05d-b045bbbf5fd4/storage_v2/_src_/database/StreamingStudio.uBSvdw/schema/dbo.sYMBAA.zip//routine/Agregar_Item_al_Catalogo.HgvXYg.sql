CREATE   PROCEDURE Agregar_Item_al_Catalogo @id_contenido INT,
                                                   @id_plataforma INT,
                                                   @reciente BIT,
                                                   @destacado BIT,
                                                   @id_en_plataforma VARCHAR(255),
                                                   @fecha_de_alta DATETIME
AS
BEGIN
    INSERT INTO dbo.Catalogo(id_contenido, id_plataforma, reciente, destacado, id_en_plataforma, fecha_de_alta,
                             fecha_de_baja, valido)
    VALUES (@id_contenido, @id_plataforma, @reciente, @destacado, @id_en_plataforma, @fecha_de_alta, NULL, 1)
END
go

