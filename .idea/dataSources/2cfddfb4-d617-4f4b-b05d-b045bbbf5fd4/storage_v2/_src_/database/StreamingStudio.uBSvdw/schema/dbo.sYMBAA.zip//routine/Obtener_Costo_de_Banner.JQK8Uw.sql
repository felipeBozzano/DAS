CREATE   PROCEDURE Obtener_Costo_de_Banner @id_banner INT
AS
BEGIN
    SELECT tamaño_de_banner, costo
    FROM dbo.Banner
    WHERE id_banner = @id_banner
END
go

