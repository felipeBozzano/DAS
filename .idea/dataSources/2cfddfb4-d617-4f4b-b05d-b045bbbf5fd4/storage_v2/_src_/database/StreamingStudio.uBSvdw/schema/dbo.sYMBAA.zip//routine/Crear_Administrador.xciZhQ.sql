CREATE   PROCEDURE Crear_Administrador @usuario VARCHAR(255),
                                              @contraseña VARCHAR(255),
                                              @email VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Administrador(usuario, contraseña, email)
    VALUES (@usuario, @contraseña, @email)
END
go

