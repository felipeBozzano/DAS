CREATE   PROCEDURE Obtener_Contenido_mas_Visto @id_cliente INT = NULL
AS
BEGIN
    SELECT Ca.id_contenido, url_imagen
    FROM dbo.Catalogo Ca
             JOIN dbo.Contenido Co ON Ca.id_contenido = Co.id_contenido
    WHERE mas_visto = 1
      AND id_plataforma IN (IIF(@id_cliente IS NOT NULL,
                                (SELECT id_plataforma FROM dbo.Federacion WHERE id_cliente = @id_cliente),
                                (SELECT id_plataforma from dbo.Catalogo)))
      AND valido = 1
END
go

