CREATE   PROCEDURE Activar_Item_en_Catalogo @id_contenido INT,
                                                   @id_plataforma INT
AS
BEGIN
    UPDATE dbo.Catalogo
    SET fecha_de_alta = CURRENT_TIMESTAMP,
        valido        = 1
    WHERE id_contenido = @id_contenido
      AND id_plataforma = @id_plataforma
END
go

