CREATE   PROCEDURE Actualizar_Catalogo @id_contenido INT,
                                              @id_plataforma INT,
                                              @reciente BIT,
                                              @destacado BIT,
                                              @id_en_plataforma VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Catalogo
    SET reciente         = @reciente,
        destacado        = @destacado,
        id_en_plataforma = @id_en_plataforma
    WHERE id_contenido = @id_contenido
      AND id_plataforma = @id_plataforma
END
go

