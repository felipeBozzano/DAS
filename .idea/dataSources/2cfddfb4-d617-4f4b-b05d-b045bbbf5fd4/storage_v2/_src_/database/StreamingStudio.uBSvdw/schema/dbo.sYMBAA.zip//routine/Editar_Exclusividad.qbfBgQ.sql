CREATE   PROCEDURE Editar_Exclusividad @id_exclusividad INT,
                                              @grado_de_exclusividad VARCHAR(255),
                                              @costo FLOAT,
                                              @descripcion VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Exclusividad
    SET grado_de_exclusividad = @grado_de_exclusividad,
        costo                 = @costo,
        descripcion           = @descripcion
    WHERE id_exclusividad = @id_exclusividad
END
go

