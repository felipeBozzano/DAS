CREATE   PROCEDURE Obtener_Datos_de_Plataforma @id_plataforma INT
AS
BEGIN
    SELECT nombre_de_fantasia, razón_social, token_de_servicio, url_de_reportes, fee_de_federacion, fee_de_registro
    FROM dbo.Plataforma_de_Streaming
    WHERE id_plataforma = @id_plataforma
END
go

