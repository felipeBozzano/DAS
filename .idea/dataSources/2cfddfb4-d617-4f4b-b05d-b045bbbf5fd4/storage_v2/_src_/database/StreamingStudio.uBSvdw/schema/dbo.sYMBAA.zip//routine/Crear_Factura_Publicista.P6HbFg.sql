CREATE   PROCEDURE Crear_Factura_Publicista @id_publicista INT,
                                                   @id_factura INT
AS
BEGIN
    INSERT INTO dbo.Factura_Publicista(id_publicista, id_factura)
    VALUES (@id_publicista, @id_factura)
END
go

