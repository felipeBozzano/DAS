CREATE   PROCEDURE Eliminar_Factura_Plataforma @id_factura INT,
                                                      @id_plataforma INT
AS
BEGIN
    DELETE
    FROM dbo.Factura_Plataforma
    WHERE id_factura = @id_factura
      AND id_plataforma = @id_plataforma
END
go

