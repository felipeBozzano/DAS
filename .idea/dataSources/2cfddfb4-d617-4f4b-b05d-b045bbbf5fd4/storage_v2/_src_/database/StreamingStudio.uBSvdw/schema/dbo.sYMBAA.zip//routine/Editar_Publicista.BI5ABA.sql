CREATE   PROCEDURE Editar_Publicista @id_publicista INT,
                                            @nombre_de_fantasia VARCHAR(255),
                                            @razón_social VARCHAR(255),
                                            @email VARCHAR(255),
                                            @contraseña VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Publicista
    SET nombre_de_fantasia = @nombre_de_fantasia,
        razón_social       = @razón_social,
        email              = @email,
        contraseña         = @contraseña
    WHERE id_publicista = @id_publicista
END
go

