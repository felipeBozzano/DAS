CREATE   PROCEDURE Eliminar_Administrador @id_administrador INT
AS
BEGIN
    DELETE
    FROM dbo.Administrador
    WHERE id_administrador = @id_administrador
END
go

