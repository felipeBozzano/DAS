CREATE   PROCEDURE Modificar_Contenido @id_contenido INT,
                                              @titulo VARCHAR(255),
                                              @descripcion VARCHAR(255),
                                              @url_imagen VARCHAR(255),
                                              @clasificacion INT,
                                              @mas_visto BIT
AS
BEGIN
    UPDATE dbo.Contenido
    SET titulo        = @titulo,
        descripcion   = @descripcion,
        url_imagen    = @url_imagen,
        clasificacion = @clasificacion,
        mas_visto     = @mas_visto
    WHERE id_contenido = @id_contenido
END
go

