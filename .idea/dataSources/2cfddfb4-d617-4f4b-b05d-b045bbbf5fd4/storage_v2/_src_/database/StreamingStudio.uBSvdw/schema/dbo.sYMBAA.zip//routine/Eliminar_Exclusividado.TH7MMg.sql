CREATE   PROCEDURE Eliminar_Exclusividado @id_exclusividad INT
AS
BEGIN
    DELETE
    FROM dbo.Exclusividad
    WHERE id_exclusividad = @id_exclusividad
END
go

