CREATE   TRIGGER Dar_de_Baja_Transaccion
    ON dbo.Federacion
    AFTER DELETE
    AS
BEGIN
    UPDATE dbo.Transaccion
    SET fecha_baja = CURRENT_TIMESTAMP
    WHERE id_cliente = (SELECT id_cliente FROM deleted)
      AND id_plataforma = (SELECT id_plataforma FROM deleted)
      AND codigo_de_transaccion = (SELECT codigo_de_transaccion FROM deleted)
END
go

