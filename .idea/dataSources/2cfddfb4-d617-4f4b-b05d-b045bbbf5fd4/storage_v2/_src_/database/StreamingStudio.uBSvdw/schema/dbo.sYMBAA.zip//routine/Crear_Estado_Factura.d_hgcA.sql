CREATE   PROCEDURE Crear_Estado_Factura @id_estado SMALLINT,
                                               @descripcion VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Estado_Factura(id_estado, descripcion)
    VALUES (@id_estado, @descripcion)
END
go

