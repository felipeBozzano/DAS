CREATE   PROCEDURE Obtener_Datos_del_Contenido @id_contenido INT,
                                                      @id_plataforma INT
AS
BEGIN
    SELECT token_de_servicio, id_en_plataforma
    FROM dbo.Catalogo C
             JOIN dbo.Plataforma_de_Streaming P ON C.id_plataforma = P.id_plataforma
    WHERE C.id_contenido = @id_contenido
      AND C.id_plataforma = @id_plataforma
      AND valido = 1
END
go

