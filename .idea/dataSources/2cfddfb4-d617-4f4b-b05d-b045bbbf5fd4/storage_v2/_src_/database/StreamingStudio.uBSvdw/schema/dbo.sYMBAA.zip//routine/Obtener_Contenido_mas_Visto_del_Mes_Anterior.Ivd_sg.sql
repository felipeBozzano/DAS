CREATE   PROCEDURE Obtener_Contenido_mas_Visto_del_Mes_Anterior
AS
BEGIN
    DECLARE @PrimerDiaMesAnterior AS DATE = DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0)
    DECLARE @UltimoDiaMesAnterior AS DATE = EOMONTH(DATEADD(MONTH, -1, GETDATE()))
    SELECT TOP 100 id_contenido, COUNT(id_clic)
    FROM dbo.Clic
    WHERE fecha BETWEEN @PrimerDiaMesAnterior AND @UltimoDiaMesAnterior
    GROUP BY id_contenido
    ORDER BY COUNT(id_clic) DESC
END
go

