CREATE   PROCEDURE Enviar_Factura @id_factura INT
AS
BEGIN
    UPDATE dbo.Factura
    SET estado = 2
    WHERE id_factura = @id_factura
END
go

