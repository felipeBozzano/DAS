CREATE   PROCEDURE Eliminar_Estado_Reporte @id_estado INT
AS
BEGIN
    DELETE
    FROM dbo.Estado_Reporte
    WHERE id_estado = @id_estado
END
go

