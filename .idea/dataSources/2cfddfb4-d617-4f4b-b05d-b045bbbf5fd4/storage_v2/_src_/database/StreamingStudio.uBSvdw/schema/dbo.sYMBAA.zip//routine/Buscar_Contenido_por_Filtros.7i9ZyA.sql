CREATE   PROCEDURE Buscar_Contenido_por_Filtros @id_cliente INT,
                                                       @titulo VARCHAR(255) = NULL,
                                                       @reciente BIT = NULL,
                                                       @destacado BIT = NULL,
                                                       @clasificacion VARCHAR(255) = NULL,
                                                       @mas_visto BIT = NULL,
                                                       @genero VARCHAR(255) = NULL
AS
BEGIN
    SELECT Ca.id_contenido, url_imagen
    FROM dbo.Catalogo Ca
             JOIN dbo.Contenido Co ON Ca.id_contenido = Co.id_contenido
    WHERE valido = 1
      AND id_plataforma IN (SELECT id_plataforma FROM dbo.Federacion WHERE id_cliente = @id_cliente)
      AND (@titulo IS NULL
        OR Co.titulo LIKE '%' + @titulo + '%')
      AND (@reciente IS NULL
        OR Ca.reciente = @reciente)
      AND (@destacado IS NULL
        OR Ca.destacado = @destacado)
      AND (@clasificacion IS NULL
        OR Co.clasificacion = @clasificacion)
      AND (@mas_visto IS NULL
        OR Co.mas_visto = @mas_visto)
      AND (@genero IS NULL OR
           EXISTS (SELECT 1
                   FROM dbo.Genero_Contenido Gc
                            JOIN Genero G ON Gc.id_genero = G.id_genero
                   WHERE Gc.id_contenido = Ca.id_contenido
                     AND G.descripcion IN (SELECT value FROM STRING_SPLIT(@genero, ','))))
END
go

