CREATE   TRIGGER Registrar_Federacion
    ON dbo.Transaccion
    AFTER UPDATE
    AS
BEGIN
    INSERT INTO dbo.Federacion
    SELECT id_plataforma,
           id_cliente,
           codigo_de_transaccion,
           token,
           tipo_usuario,
           fecha_alta,
           IIF(EXISTS(SELECT 1
                      FROM dbo.Transaccion
                      WHERE Transaccion.id_plataforma = inserted.id_plataforma
                        AND Transaccion.id_cliente = inserted.id_cliente
                        AND Transaccion.facturada = 1), 1, 0)
    FROM inserted
    WHERE inserted.fecha_baja IS NULL
      AND inserted.token IS NOT NULL
END
go

