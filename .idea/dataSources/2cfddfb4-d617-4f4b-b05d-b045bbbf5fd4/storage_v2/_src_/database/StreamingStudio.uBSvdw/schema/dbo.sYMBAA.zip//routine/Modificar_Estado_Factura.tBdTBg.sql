CREATE   PROCEDURE Modificar_Estado_Factura @id_estado SMALLINT,
                                                   @descripcion VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Estado_Factura
    SET descripcion = @descripcion
    WHERE id_estado = @id_estado
END
go

