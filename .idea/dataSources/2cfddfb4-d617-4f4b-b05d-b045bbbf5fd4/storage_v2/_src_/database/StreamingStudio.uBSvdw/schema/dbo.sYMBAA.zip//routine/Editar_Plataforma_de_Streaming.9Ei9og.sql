CREATE   PROCEDURE Editar_Plataforma_de_Streaming @id_plataforma INT,
                                                         @nombre_de_fantasia VARCHAR(255),
                                                         @razón_social VARCHAR(255),
                                                         @url_imagen VARCHAR(255),
                                                         @token_de_servicio VARCHAR(255),
                                                         @url_de_reportes VARCHAR(255),
                                                         @url_de_sesion VARCHAR(255),
                                                         @fee_de_federeacion FLOAT,
                                                         @fee_de_registro FLOAT
AS
BEGIN
    UPDATE Plataforma_de_Streaming
    SET nombre_de_fantasia = @nombre_de_fantasia,
        razón_social       = @razón_social,
        url_imagen         = @url_imagen,
        token_de_servicio  = @token_de_servicio,
        url_de_reportes    = @url_de_reportes,
        url_de_sesion      = @url_de_sesion,
        fee_de_federacion  = @fee_de_federeacion,
        fee_de_registro    = @fee_de_registro
    WHERE id_plataforma = @id_plataforma
END
go

