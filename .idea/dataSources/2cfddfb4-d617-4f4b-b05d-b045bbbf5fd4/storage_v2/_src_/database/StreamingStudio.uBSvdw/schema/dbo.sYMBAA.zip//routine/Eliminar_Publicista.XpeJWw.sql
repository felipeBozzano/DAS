CREATE   PROCEDURE Eliminar_Publicista @id_publicista INT
AS
BEGIN
    DELETE
    FROM dbo.Publicista
    WHERE id_publicista = @id_publicista
END
go

