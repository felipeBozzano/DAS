CREATE   PROCEDURE Eliminar_Banner @id_banner INT
AS
BEGIN
    DELETE
    FROM dbo.Banner
    WHERE id_banner = @id_banner
END
go

