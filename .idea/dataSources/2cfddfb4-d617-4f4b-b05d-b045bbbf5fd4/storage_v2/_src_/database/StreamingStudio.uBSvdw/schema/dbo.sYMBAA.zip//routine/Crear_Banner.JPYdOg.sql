CREATE   PROCEDURE Crear_Banner @tamaño_de_banner VARCHAR(255),
                                       @costo FLOAT,
                                       @descripcion VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Banner(tamaño_de_banner, costo, descripcion)
    VALUES (@tamaño_de_banner, @costo, @descripcion)
END
go

