CREATE   PROCEDURE Editar_Publicidad @id_publicidad INT,
                                            @id_publicista VARCHAR(255),
                                            @id_exclusividad VARCHAR(255),
                                            @id_banner VARCHAR(255),
                                            @codigo_publicidad VARCHAR(255),
                                            @url_de_imagen VARCHAR(255),
                                            @url_de_publicidad VARCHAR(255),
                                            @fecha_de_alta DATE,
                                            @fecha_de_baja DATE
AS
BEGIN
    UPDATE dbo.Publicidad
    SET id_publicista     = @id_publicista,
        id_exclusividad   = @id_exclusividad,
        id_banner         = @id_banner,
        codigo_publicidad = @codigo_publicidad,
        url_de_imagen     = @url_de_imagen,
        url_de_publicidad = @url_de_publicidad,
        fecha_de_alta     = @fecha_de_alta,
        fecha_de_baja     = @fecha_de_baja
    WHERE id_publicidad = @id_publicidad
END
go

