CREATE   PROCEDURE Obtener_Estadisticas_para_Publicistas
AS
BEGIN
    SELECT P.id_publicista, P.id_publicidad, P.codigo_publicidad, count(c.id_clic) AS cantidad_de_clics
    FROM dbo.Publicidad P
             JOIN dbo.Clic C ON P.id_publicidad = C.id_publicidad
    WHERE C.id_publicidad IS NOT NULL
      AND fecha BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0)
        AND DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)
    GROUP BY P.id_publicista, P.id_publicidad, P.codigo_publicidad
END
go

