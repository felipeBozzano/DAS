CREATE   PROCEDURE Modificar_Estado_Reporte @id_estado SMALLINT,
                                                   @descripcion VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Estado_Reporte
    SET descripcion = @descripcion
    WHERE id_estado = @id_estado
END
go

