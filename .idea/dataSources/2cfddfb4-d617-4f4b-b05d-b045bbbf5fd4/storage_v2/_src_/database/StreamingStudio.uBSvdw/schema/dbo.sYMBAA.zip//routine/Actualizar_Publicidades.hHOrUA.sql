CREATE   PROCEDURE Actualizar_Publicidades @id_publicidad INT,
                                                  @url_de_imagen VARCHAR(255),
                                                  @url_de_publicidad VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Publicidad
    SET url_de_imagen     = @url_de_imagen,
        url_de_publicidad = @url_de_publicidad
    WHERE id_publicidad = @id_publicidad
END
go

