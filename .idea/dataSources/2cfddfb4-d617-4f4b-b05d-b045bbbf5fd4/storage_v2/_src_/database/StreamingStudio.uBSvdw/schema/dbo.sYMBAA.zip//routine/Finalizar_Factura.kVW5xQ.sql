CREATE   PROCEDURE Finalizar_Factura @id_factura INT,
                                            @total VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Factura
    SET total  = @total,
        estado = 1
    WHERE id_factura = @id_factura
END
go

