CREATE   PROCEDURE Desvincular_Federacion @id_plataforma INT,
                                                 @id_cliente INT
AS
BEGIN
    DELETE
    FROM Federacion
    WHERE id_plataforma = @id_plataforma
      and id_cliente = @id_cliente
END
go

