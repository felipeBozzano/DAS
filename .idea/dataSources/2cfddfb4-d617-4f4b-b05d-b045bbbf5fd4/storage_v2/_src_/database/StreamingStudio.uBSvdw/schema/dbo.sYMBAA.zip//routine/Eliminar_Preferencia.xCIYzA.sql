CREATE   PROCEDURE Eliminar_Preferencia @id_genero INT,
                                               @id_cliente INT
AS
BEGIN
    DELETE
    FROM dbo.Preferencia
    WHERE id_genero = @id_genero
      AND id_cliente = @id_cliente
END
go

