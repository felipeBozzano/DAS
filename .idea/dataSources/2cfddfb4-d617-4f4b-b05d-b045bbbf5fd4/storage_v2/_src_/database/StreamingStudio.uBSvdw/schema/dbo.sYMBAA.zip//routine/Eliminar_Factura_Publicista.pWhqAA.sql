CREATE   PROCEDURE Eliminar_Factura_Publicista @id_publicista INT,
                                                      @id_factura INT
AS
BEGIN
    DELETE
    FROM dbo.Factura_Publicista
    WHERE id_publicista = @id_publicista
      AND id_factura = @id_factura
END
go

