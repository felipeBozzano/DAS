CREATE   PROCEDURE Obtener_Datos_de_Federaciones
AS
BEGIN
    SELECT id_plataforma, tipo_usuario, count(id_cliente) AS cantidad_de_federaciones
    FROM dbo.Federacion
    WHERE fecha_alta BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0)
        AND DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)
      AND facturada = 0
    GROUP BY id_plataforma, tipo_usuario
END
go

