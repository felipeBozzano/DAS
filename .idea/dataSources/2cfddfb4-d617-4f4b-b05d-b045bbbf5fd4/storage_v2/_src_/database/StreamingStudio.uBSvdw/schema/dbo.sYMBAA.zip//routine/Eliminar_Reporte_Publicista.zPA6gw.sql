CREATE   PROCEDURE Eliminar_Reporte_Publicista @id_publicista INT,
                                                      @id_reporte INT
AS
BEGIN
    DELETE
    FROM dbo.Reporte_Publicista
    WHERE id_publicista = @id_publicista
      AND id_reporte = @id_reporte
END
go

