CREATE   PROCEDURE Modificar_Detalle_Reporte @id_reporte INT,
                                                    @id_detalle INT,
                                                    @descripcion VARCHAR(255),
                                                    @cantidad_de_clics INT
AS
BEGIN
    UPDATE dbo.Detalle_Reporte
    SET cantidad_de_clics = @cantidad_de_clics,
        descripcion       = @descripcion
    WHERE id_reporte = @id_reporte
      AND id_detalle = @id_detalle
END
go

