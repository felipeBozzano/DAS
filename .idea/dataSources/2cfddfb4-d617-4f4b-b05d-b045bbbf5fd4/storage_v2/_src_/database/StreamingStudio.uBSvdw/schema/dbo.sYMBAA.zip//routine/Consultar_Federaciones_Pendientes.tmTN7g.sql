CREATE   PROCEDURE Consultar_Federaciones_Pendientes
AS
BEGIN
    SELECT id_plataforma, id_cliente, codigo_de_transaccion, tipo_usuario, email_interno
    FROM dbo.Transaccion
    WHERE token IS NULL
      AND fecha_baja IS NOT NULL
END
go

