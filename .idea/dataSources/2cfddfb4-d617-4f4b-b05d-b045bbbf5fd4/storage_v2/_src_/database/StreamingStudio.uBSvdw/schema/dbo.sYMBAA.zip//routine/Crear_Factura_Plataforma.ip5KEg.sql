CREATE   PROCEDURE Crear_Factura_Plataforma @id_factura INT,
                                                   @id_plataforma INT
AS
BEGIN
    INSERT INTO dbo.Factura_Plataforma(id_factura, id_plataforma)
    VALUES (@id_factura, @id_plataforma)
END
go

