CREATE   PROCEDURE Crear_Detalle_Factura @id_factura INT,
                                                @precio_unitario FLOAT,
                                                @cantidad INT,
                                                @subtotal FLOAT,
                                                @descripcion VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Detalle_Factura(id_factura, precio_unitario, cantidad, subtotal, descripcion)
    VALUES (@id_factura, @precio_unitario, @cantidad, @subtotal, @descripcion)
END
go

