CREATE   PROCEDURE Obtener_Datos_de_Publicista @id_publicista INT
AS
BEGIN
    SELECT nombre_de_fantasia, razón_social, token_de_servicio, url_de_reportes
    FROM dbo.Publicista
    WHERE id_publicista = @id_publicista
END
go

