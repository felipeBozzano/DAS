CREATE   PROCEDURE Finalizar_Reporte @id_reporte INT,
                                            @total VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Reporte
    SET total  = @total,
        estado = 1
    WHERE id_reporte = @id_reporte
END
go

