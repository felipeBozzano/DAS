CREATE   PROCEDURE Crear_Reporte_Publicista @id_publicista INT,
                                                   @id_reporte INT
AS
BEGIN
    INSERT INTO dbo.Reporte_Publicista(id_publicista, id_reporte)
    VALUES (@id_publicista, @id_reporte)
END
go

