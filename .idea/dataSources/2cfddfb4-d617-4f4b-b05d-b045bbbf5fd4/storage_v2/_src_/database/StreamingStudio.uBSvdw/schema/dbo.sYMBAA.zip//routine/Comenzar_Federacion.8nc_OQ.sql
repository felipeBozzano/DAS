CREATE   PROCEDURE Comenzar_Federacion @id_plataforma INT,
                                              @id_cliente INT,
                                              @codigo_de_transaccion VARCHAR(255),
                                              @tipo_usuario VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Transaccion(id_plataforma, id_cliente, codigo_de_transaccion, token, tipo_usuario, fecha_alta,
                                fecha_baja, email_interno, email_externo)
    VALUES (@id_plataforma, @id_cliente, @codigo_de_transaccion, NULL, @tipo_usuario, CURRENT_TIMESTAMP, NULL,
            (SELECT email FROM dbo.Cliente_Usuario WHERE id_cliente = @id_cliente), NULL)
END
go

