CREATE   PROCEDURE Eliminar_Plataforma_de_Streaming @id_plataforma INT
AS
BEGIN
    DELETE
    FROM Plataforma_de_Streaming
    WHERE id_plataforma = @id_plataforma
END
go

