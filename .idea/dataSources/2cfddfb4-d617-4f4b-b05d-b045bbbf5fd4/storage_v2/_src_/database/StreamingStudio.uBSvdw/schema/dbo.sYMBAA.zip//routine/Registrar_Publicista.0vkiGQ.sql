CREATE   PROCEDURE Registrar_Publicista @nombre_de_fantasia VARCHAR(255),
                                               @razón_social VARCHAR(255),
                                               @email VARCHAR(255),
                                               @contraseña VARCHAR(255),
                                               @token_de_servicio VARCHAR(255),
                                               @url_de_reportes VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Publicista(nombre_de_fantasia, razón_social, email, contraseña, token_de_servicio, url_de_reportes)
    VALUES (@nombre_de_fantasia, @razón_social, @email, @contraseña, @token_de_servicio, @url_de_reportes)
END
go

