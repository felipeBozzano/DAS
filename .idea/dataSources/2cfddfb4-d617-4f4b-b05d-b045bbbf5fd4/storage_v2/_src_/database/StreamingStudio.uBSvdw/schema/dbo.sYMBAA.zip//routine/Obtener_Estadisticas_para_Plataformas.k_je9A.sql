CREATE   PROCEDURE Obtener_Estadisticas_para_Plataformas
AS
BEGIN
    SELECT Cc.id_plataforma, Cc.id_contenido, Co.id_en_plataforma, COUNT(id_clic) AS cantidad_de_clics
    FROM dbo.Clic Cc
             JOIN dbo.Catalogo Co ON Cc.id_contenido = Co.id_contenido AND Cc.id_plataforma = Co.id_plataforma
    WHERE Cc.id_contenido IS NOT NULL
      AND Cc.id_plataforma IS NOT NULL
      AND Co.valido = 1
      AND Cc.fecha BETWEEN DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()) - 1, 0)
        AND DATEADD(MONTH, DATEDIFF(MONTH, 0, GETDATE()), 0)
    GROUP BY Cc.id_plataforma, Cc.id_contenido, Co.id_en_plataforma
END
go

