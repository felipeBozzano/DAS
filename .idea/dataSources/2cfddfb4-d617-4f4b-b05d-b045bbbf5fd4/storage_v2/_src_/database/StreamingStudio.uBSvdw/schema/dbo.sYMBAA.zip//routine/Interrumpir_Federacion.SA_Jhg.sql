CREATE   PROCEDURE Interrumpir_Federacion @id_plataforma INT,
                                                 @id_cliente INT,
                                                 @codigo_de_transaccion VARCHAR(255)
AS
BEGIN
    UPDATE Transaccion
    SET fecha_baja = CURRENT_TIMESTAMP
    WHERE id_plataforma = @id_plataforma
      and id_cliente = @id_cliente
      and codigo_de_transaccion = @codigo_de_transaccion
END
go

