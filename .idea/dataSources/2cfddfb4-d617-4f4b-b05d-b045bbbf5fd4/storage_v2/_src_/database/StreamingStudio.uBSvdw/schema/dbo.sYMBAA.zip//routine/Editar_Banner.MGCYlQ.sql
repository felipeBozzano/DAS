CREATE   PROCEDURE Editar_Banner @id_banner INT,
                                        @tamaño_de_banner VARCHAR(255),
                                        @costo FLOAT,
                                        @descripcion VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Banner
    SET tamaño_de_banner = @tamaño_de_banner,
        costo            = @costo,
        descripcion      = @descripcion
    WHERE id_banner = @id_banner
END
go

