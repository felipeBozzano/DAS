CREATE   PROCEDURE Obtener_Url_de_Sesion @id_plataforma INT
AS
BEGIN
    SELECT url_de_sesion
    FROM dbo.Plataforma_de_Streaming
    WHERE id_plataforma = @id_plataforma
END
go

