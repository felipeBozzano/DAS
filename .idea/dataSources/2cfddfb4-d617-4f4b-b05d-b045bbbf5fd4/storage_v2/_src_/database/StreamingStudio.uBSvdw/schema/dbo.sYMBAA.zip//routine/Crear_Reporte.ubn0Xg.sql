CREATE   PROCEDURE Crear_Reporte
AS
BEGIN
    INSERT INTO dbo.Reporte(total, fecha, estado)
    VALUES (0, (SELECT CONVERT(date, CURRENT_TIMESTAMP)), 0)
END
go

