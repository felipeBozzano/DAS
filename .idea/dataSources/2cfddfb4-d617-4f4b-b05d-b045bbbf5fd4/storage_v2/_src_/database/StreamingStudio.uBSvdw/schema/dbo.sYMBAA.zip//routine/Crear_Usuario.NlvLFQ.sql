CREATE   PROCEDURE Crear_Usuario @usuario VARCHAR(255),
                                        @contraseña VARCHAR(255),
                                        @email VARCHAR(255),
                                        @nombre VARCHAR(255),
                                        @apellido VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Cliente_Usuario(usuario, contraseña, email, nombre, apellido, valido)
    VALUES (@usuario, @contraseña, @email, @nombre, @apellido, 0)
END
go

