CREATE   PROCEDURE Obtener_Catalogo_Actual
AS
BEGIN
    SELECT id_plataforma, id_contenido, reciente, destacado, id_en_plataforma
    FROM dbo.Catalogo
    WHERE valido = 1
END
go

