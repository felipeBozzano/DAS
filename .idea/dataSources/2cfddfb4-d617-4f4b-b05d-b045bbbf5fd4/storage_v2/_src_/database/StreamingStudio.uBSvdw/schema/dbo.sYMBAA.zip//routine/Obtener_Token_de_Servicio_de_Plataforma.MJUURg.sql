CREATE   PROCEDURE Obtener_Token_de_Servicio_de_Plataforma @id_plataforma INT
AS
BEGIN
    SELECT token_de_servicio
    FROM dbo.Plataforma_de_Streaming
    WHERE id_plataforma = @id_plataforma
END
go

