CREATE   PROCEDURE Cancelar_Factura @id_factura INT
AS
BEGIN
    UPDATE dbo.Factura
    SET estado = -1
    WHERE id_factura = @id_factura
END
go

