CREATE   PROCEDURE Actualizar_Contenido_mas_Visto @id_contenido INT,
                                                         @mas_visto BIT
AS
BEGIN
    UPDATE dbo.Contenido
    SET mas_visto = @mas_visto
    WHERE id_contenido = @id_contenido
END
go

