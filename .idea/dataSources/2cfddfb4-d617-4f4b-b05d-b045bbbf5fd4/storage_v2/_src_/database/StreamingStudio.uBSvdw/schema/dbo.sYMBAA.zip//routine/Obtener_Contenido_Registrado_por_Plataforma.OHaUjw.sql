CREATE   PROCEDURE Obtener_Contenido_Registrado_por_Plataforma @id_plataforma INT
AS
BEGIN
    SELECT id_contenido, reciente, destacado, id_en_plataforma
    FROM dbo.Catalogo
    WHERE id_plataforma = @id_plataforma
END
go

