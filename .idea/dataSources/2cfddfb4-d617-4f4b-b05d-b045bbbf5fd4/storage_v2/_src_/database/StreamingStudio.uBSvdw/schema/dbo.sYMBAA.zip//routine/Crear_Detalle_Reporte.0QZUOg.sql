CREATE   PROCEDURE Crear_Detalle_Reporte @id_reporte INT,
                                                @descripcion VARCHAR(255),
                                                @cantidad_de_clics INT
AS
BEGIN
    INSERT INTO dbo.Detalle_Reporte(id_reporte, descripcion, cantidad_de_clics)
    VALUES (@id_reporte, @descripcion, @cantidad_de_clics)
END
go

