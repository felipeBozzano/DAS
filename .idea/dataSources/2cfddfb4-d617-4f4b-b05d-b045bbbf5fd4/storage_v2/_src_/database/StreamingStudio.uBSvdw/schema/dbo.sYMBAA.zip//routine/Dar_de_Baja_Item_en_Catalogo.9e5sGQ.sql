CREATE   PROCEDURE Dar_de_Baja_Item_en_Catalogo @id_contenido INT,
                                                       @id_plataforma INT
AS
BEGIN
    UPDATE dbo.Catalogo
    SET fecha_de_baja = CURRENT_TIMESTAMP,
        valido        = 0
    WHERE id_contenido = @id_contenido
      AND id_plataforma = @id_plataforma
END
go

