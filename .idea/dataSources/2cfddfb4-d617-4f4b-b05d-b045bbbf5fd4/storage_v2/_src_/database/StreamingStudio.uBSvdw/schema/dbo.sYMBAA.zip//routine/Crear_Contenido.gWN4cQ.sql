CREATE   PROCEDURE Crear_Contenido @titulo VARCHAR(255),
                                          @descripcion VARCHAR(255),
                                          @url_imagen VARCHAR(255),
                                          @clasificacion INT,
                                          @mas_visto BIT
AS
BEGIN
    INSERT INTO dbo.Contenido(titulo, descripcion, url_imagen, clasificacion, mas_visto)
    VALUES (@titulo, @descripcion, @url_imagen, @clasificacion, @mas_visto)
END
go

