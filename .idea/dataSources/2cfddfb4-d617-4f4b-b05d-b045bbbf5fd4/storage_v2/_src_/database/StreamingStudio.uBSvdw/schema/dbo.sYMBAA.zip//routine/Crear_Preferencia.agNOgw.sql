CREATE   PROCEDURE Crear_Preferencia @id_genero INT,
                                            @id_cliente INT
AS
BEGIN
    INSERT INTO dbo.Preferencia(id_genero, id_cliente)
    VALUES (@id_genero, @id_cliente)
END
go

