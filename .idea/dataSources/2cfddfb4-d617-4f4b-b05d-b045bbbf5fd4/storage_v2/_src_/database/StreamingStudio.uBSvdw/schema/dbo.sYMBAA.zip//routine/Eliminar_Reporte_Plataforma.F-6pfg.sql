CREATE   PROCEDURE Eliminar_Reporte_Plataforma @id_reporte INT,
                                                      @id_plataforma INT
AS
BEGIN
    DELETE
    FROM dbo.Reporte_Plataforma
    WHERE id_reporte = @id_reporte
      AND id_plataforma = @id_plataforma
END
go

