CREATE   PROCEDURE Eliminar_Detalle_Factura @id_factura INT,
                                                   @id_detalle INT
AS
BEGIN
    DELETE
    FROM dbo.Detalle_Factura
    WHERE id_factura = @id_factura
      AND id_detalle = @id_detalle
END
go

