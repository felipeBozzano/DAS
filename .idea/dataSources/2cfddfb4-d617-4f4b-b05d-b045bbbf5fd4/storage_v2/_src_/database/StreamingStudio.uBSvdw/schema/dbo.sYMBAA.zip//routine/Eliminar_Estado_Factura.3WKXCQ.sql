CREATE   PROCEDURE Eliminar_Estado_Factura @id_estado INT
AS
BEGIN
    DELETE
    FROM dbo.Estado_Factura
    WHERE id_estado = @id_estado
END
go

