CREATE   PROCEDURE Crear_Factura
AS
BEGIN
    INSERT INTO dbo.Factura(total, fecha, estado)
    VALUES (0, (SELECT CONVERT(date, CURRENT_TIMESTAMP)), 0)
END
go

