CREATE   PROCEDURE Crear_Estado_Reporte @id_estado SMALLINT,
                                               @descripcion VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Estado_Reporte(id_estado, descripcion)
    VALUES (@id_estado, @descripcion)
END
go

