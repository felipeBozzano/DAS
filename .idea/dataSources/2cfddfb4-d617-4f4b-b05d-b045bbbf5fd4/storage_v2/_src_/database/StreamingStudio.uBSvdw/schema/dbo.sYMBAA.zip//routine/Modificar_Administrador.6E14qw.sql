CREATE   PROCEDURE Modificar_Administrador @id_administrador INT,
                                                  @usuario VARCHAR(255),
                                                  @contraseña VARCHAR(255),
                                                  @email VARCHAR(255)
AS
BEGIN
    UPDATE dbo.Administrador
    SET usuario    = @usuario,
        contraseña = @contraseña,
        email      = @email
    WHERE id_administrador = @id_administrador
END
go

