CREATE   PROCEDURE Obtener_Contenido_mas_Visto_Actual
AS
BEGIN
    SELECT id_contenido
    FROM dbo.Contenido
    WHERE mas_visto = 1
END
go

