CREATE   PROCEDURE Crear_Reporte_Plataforma @id_reporte INT,
                                                   @id_plataforma INT
AS
BEGIN
    INSERT INTO dbo.Reporte_Plataforma(id_reporte, id_plataforma)
    VALUES (@id_reporte, @id_plataforma)
END
go

