CREATE   PROCEDURE Eliminar_Detalle_Reporte @id_reporte INT,
                                                   @id_detalle INT
AS
BEGIN
    DELETE
    FROM dbo.Detalle_Reporte
    WHERE id_reporte = @id_reporte
      AND id_detalle = @id_detalle
END
go

