CREATE   PROCEDURE Crear_Exclusividad @grado_de_exclusividad VARCHAR(255),
                                             @costo FLOAT,
                                             @descripcion VARCHAR(255)
AS
BEGIN
    INSERT INTO dbo.Exclusividad(grado_de_exclusividad, costo, descripcion)
    VALUES (@grado_de_exclusividad, @costo, @descripcion)
END
go

