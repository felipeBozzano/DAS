CREATE   PROCEDURE Eliminar_Publicidad @id_publicidad INT
AS
BEGIN
    DELETE
    FROM dbo.Publicidad
    WHERE id_publicidad = @id_publicidad
END
go

