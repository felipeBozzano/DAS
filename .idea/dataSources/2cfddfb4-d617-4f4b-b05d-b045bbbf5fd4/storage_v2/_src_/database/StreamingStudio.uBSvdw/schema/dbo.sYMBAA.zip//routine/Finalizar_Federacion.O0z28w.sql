CREATE   PROCEDURE Finalizar_Federacion @id_plataforma INT,
                                               @id_cliente INT,
                                               @codigo_de_transaccion VARCHAR(255),
                                               @token VARCHAR(255),
                                               @email_externo VARCHAR(255)
AS
BEGIN
    UPDATE Transaccion
    SET token         = @token,
        email_externo = @email_externo
    WHERE id_plataforma = @id_plataforma
      and id_cliente = @id_cliente
      and codigo_de_transaccion = @codigo_de_transaccion
END
go

